# 1.1.0

- Updated to new SkinDefParams system

# 1.0.5

- Hunk update
- Merged dlls
- Restrict weapon reskins to the chief skin.
    - Global weapon reskins can be re-enabled in the config
- Changed load process to be quicker

# 1.0.4

- Added Changelog

