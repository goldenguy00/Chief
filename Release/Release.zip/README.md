# Lets try shooting our way out. Mix it up a little

![](https://github.com/LONK117/Chief/blob/main/20241216194940_1.jpg?raw=true)

This mod adds a Master Chief skin for HUNK, and also adds Halo/Halo inspired weapons to replace the guns in HUNK's kit.

![](https://github.com/LONK117/Chief/blob/main/20241217180156_1.jpg?raw=true)


# Future Plans:The goal is to replace every single weapon in Hunk's arsenal with a Halo gun. Possibly add more character skins too. 
# Known issues: Dunno any... Yet-
Credits: VCR, thanks for guiding me through how to use Blender
.Score handled the Unity/ Code side of the project. Wouldn't be possible without him

Magnum model: https://sketchfab.com/3d-models/halo-magnum-66ce74596dcb44aea040713573e2fc4f
SMG model: https://sketchfab.com/3d-models/halo-2-anniversary-smg-b750ee3892c1427ab9e768313ba38f6d

